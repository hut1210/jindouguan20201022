// $('.sidebar  ul li').click(function() {
//     $('.a_txt2:visible').slideUp().siblings().removeClass('a_js2_on');
//     $('.sidebar  ul li').find(".a_js_jia").css('display','flex');
//     $('.sidebar  ul li').find(".a_js_jian").css('display','none');
//     var subnav = $(this).find('.a_txt2');
//     if(subnav.is(':hidden')) {
//         subnav.slideDown().prev().addClass('a_js2_on');
//         $(this).find(".a_js_jia").css('display','none');
//         $(this).find(".a_js_jian").css('display','flex');
//     } else {
//         subnav.slideUp().prev().removeClass('a_js2_on');
//         $(this).find(".a_js_jia").css('display','flex');
//         $(this).find(".a_js_jian").css('display','none');
//     };
// })
//
